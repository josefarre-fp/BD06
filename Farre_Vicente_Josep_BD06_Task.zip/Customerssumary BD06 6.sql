DROP FUNCTION IF EXISTS customer_summary;

DELIMITER $$

CREATE FUNCTION customer_summary (customer_id INT) 
RETURNS VARCHAR(255)
DETERMINISTIC -- Explicación de la función (Function explain)
READS SQL DATA
BEGIN
    DECLARE orders_count INT DEFAULT 0;
    DECLARE products_count INT DEFAULT 0;

    SELECT COUNT(*) 
    INTO orders_count
    FROM orders
    WHERE customerNumber = customer_id;

    IF orders_count = 0 THEN
        RETURN 'No orders or products';
    END IF;

    SELECT COUNT(*)
    INTO products_count
    FROM orderdetails od
    JOIN orders o ON od.orderNumber = o.orderNumber
    WHERE o.customerNumber = customer_id;

    RETURN CONCAT(
        orders_count, ' order/s and ',
        products_count, ' product/s'
    );
END$$

DELIMITER ;
SELECT customerNumber, customerName, customer_summary(customerNumber) AS summary
FROM customers
LIMIT 10;


