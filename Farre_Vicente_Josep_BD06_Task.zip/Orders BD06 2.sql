DROP TRIGGER IF EXISTS before_insert_order;

DELIMITER $$

CREATE TRIGGER before_insert_order
BEFORE INSERT ON orders
FOR EACH ROW
BEGIN
    IF (
        SELECT COUNT(*) 
        FROM orders 
        WHERE customerNumber = NEW.customerNumber 
        AND status IN ('In Process', 'On Hold', 'Shipped')
    ) >= 3 THEN
        
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'A customer cannot have more than 3 active orders';
    END IF;
END$$

DELIMITER ;

INSERT INTO orders 
VALUES (60001, '2024-01-10', '2024-01-20', NULL, 'In Process', NULL, 202);

