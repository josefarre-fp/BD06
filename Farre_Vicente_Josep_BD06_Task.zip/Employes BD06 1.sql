SELECT * FROM classicmodels.employees;
USE classicmodels;

DROP TRIGGER IF EXISTS before_insert_sales_manager;

DELIMITER $$

CREATE TRIGGER before_insert_sales_manager
BEFORE INSERT ON employees
FOR EACH ROW
BEGIN
    -- Usamos LIKE '%Sales Manager%' para capturar variaciones como (APAC) o (EMEA)
    IF NEW.jobTitle LIKE '%Sales Manager%' THEN
        -- Verificamos si ya existe alguien con ese cargo en la misma oficina
        IF (SELECT COUNT(*) 
            FROM employees 
            WHERE jobTitle LIKE '%Sales Manager%'
            AND officeCode = NEW.officeCode) >= 1 THEN
            
            SIGNAL SQLSTATE '45000' 
            SET MESSAGE_TEXT = 'Only one Sales Manager is allowed per office'; -- Mensaje sugerido en el PDF
        END IF;
    END IF;
END$$

DELIMITER ;

INSERT INTO employees 
VALUES (3002, 'Brown', 'Laura', 'x112', 'laura.brown@classicmodels.com', 3, 1002, 'Sales Manager');

