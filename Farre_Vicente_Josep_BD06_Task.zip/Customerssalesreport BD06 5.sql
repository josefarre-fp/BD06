DROP PROCEDURE IF EXISTS customers_sales_report;

DELIMITER $$

CREATE PROCEDURE customers_sales_report(
    IN office_name VARCHAR(50),
    IN year_param INT,
    OUT sales_report LONGTEXT -- Usamos LONGTEXT por si el reporte es muy extenso 
)
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE line TEXT;
    
    -- El cursor debe separar la lógica de obtención de datos de la de formateo
    DECLARE cur CURSOR FOR
    SELECT 
        CONCAT(
            '** Employee: ', e.firstName, ' ', e.lastName, 
            ' ** Customer: ', c.customerName, 
            ' ** Total Sales: ', FORMAT(SUM(od.quantityOrdered * od.priceEach), 2)
        )
    FROM employees e
    JOIN offices o2 ON e.officeCode = o2.officeCode
    JOIN customers c ON e.employeeNumber = c.salesRepEmployeeNumber
    JOIN orders o ON c.customerNumber = o.customerNumber
    JOIN orderdetails od ON o.orderNumber = od.orderNumber
    WHERE o2.city = office_name
      AND YEAR(o.orderDate) = year_param
    -- Agrupamos por los campos que identifican al empleado y cliente para evitar errores de SQL 
    GROUP BY e.employeeNumber, c.customerNumber;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    SET sales_report = '';

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO line;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Concatenamos cada línea con un salto de línea 
        SET sales_report = CONCAT(sales_report, line, '\n');
    END LOOP;

    CLOSE cur;

    -- Validamos si el reporte está vacío para devolver el mensaje personalizado [cite: 189, 220]
    IF sales_report = '' THEN
        SET sales_report = CONCAT('No sales data available for office "', office_name, '" in year ', year_param);
    END IF;
END$$

DELIMITER ;
CALL customers_sales_report('San Francisco', 2003, @report);
SELECT @report;