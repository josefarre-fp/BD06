DROP TRIGGER IF EXISTS before_insert_orderdetails;

DELIMITER $$

CREATE TRIGGER before_insert_orderdetails
BEFORE INSERT ON orderdetails
FOR EACH ROW
BEGIN
    DECLARE stock INT;

    SELECT quantityInStock 
    INTO stock
    FROM products
    WHERE productCode = NEW.productCode;

    IF stock IS NULL THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Product does not exist';
        
    ELSEIF stock = 0 THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Product out of stock';
        
    ELSEIF stock < NEW.quantityOrdered THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Insufficient stock';
    END IF;
END$$
DELIMITER ;

INSERT INTO orderdetails 
VALUES (10100, 'INVALID_CODE', 5, 50.00, 3);