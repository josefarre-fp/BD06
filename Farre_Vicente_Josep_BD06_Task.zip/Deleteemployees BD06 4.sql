DROP PROCEDURE IF EXISTS delete_employee;

DELIMITER $$

CREATE PROCEDURE delete_employee (IN pid INT)
BEGIN
    DECLARE emp_name VARCHAR(200);
    DECLARE boss_id INT;
    DECLARE boss_name VARCHAR(200);

    SELECT CONCAT(firstName, ' ', lastName), reportsTo
    INTO emp_name, boss_id
    FROM employees
    WHERE employeeNumber = pid;

    IF emp_name IS NULL THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'Employee does not exist';

    ELSEIF boss_id IS NULL THEN
        SIGNAL SQLSTATE '45000' 
        SET MESSAGE_TEXT = 'The president cannot be deleted';

    ELSE
        UPDATE customers 
        SET salesRepEmployeeNumber = boss_id 
        WHERE salesRepEmployeeNumber = pid;

        UPDATE employees 
        SET reportsTo = boss_id 
        WHERE reportsTo = pid;

        DELETE FROM employees 
        WHERE employeeNumber = pid;

        SELECT CONCAT(firstName, ' ', lastName)
        INTO boss_name
        FROM employees
        WHERE employeeNumber = boss_id;

        SELECT CONCAT(
            'Employee ', emp_name, 
            ' deleted. Reassigned to ', boss_name
        ) AS message;
    END IF;
END$$

DELIMITER ;
CALL delete_employee(1002); 